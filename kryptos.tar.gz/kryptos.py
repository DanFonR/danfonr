#k1: vigenere, kw: palimpsest
#k2: vigenere, kw: abscissa
#k3: clockwise rotations, 42×8 to 8×42, write as 14×24, 14×24 to 24×14
#k4 possibly stacking ciphers
#FLRV = EAST; QQPRNGKSS = NORTHEAST; MZFPK = CLOCK; NYPVTT = BERLIN

from collections import Counter
from pandas import DataFrame

def decrypt(cipher, key):
	cipher = list(cipher.upper())
	length = len(cipher)
	key = ((key * length)[:length]).upper()

	for i in range(length):
		cipher[i] = chr((ord(cipher[i]) - ord(key[i])) % 26 + 65)

	return "".join(cipher)

ciphertxt = \
"OBKRUOXOGHULBSOLIFBBWFLRVQQPRNGKSSOTWTQSJQSSEKZZWATJKLUDIAWINFBNYPVTTMZFPKWGDKZXTJCDIGKUHUAUEKCAR"
somewords = \
"OBKRUOXOGHULBSOLIFBBWEASTNORTHEASTOTWTQSJQSSEKZZWATJKLUDIAWINFBBERLINCLOCKWGDKZXTJCDIGKUHUAUEKCAR"
reverse = ciphertxt[::-1]

cipherfrequency = Counter(ciphertxt)
expected = {'E': 10, 'A': 8, 'R': 7, 'I': 7, 'O': 6, 'T': 6, 'N': 6, 'S': 5,
'L': 5, 'C': 4, 'U': 3, 'D': 3, 'P': 3, 'M': 2, 'H': 2, 'G': 2, 'B': 2,
'F': 1, 'Y': 1, 'W': 1, 'K': 1, 'V': 0, 'X': 0, 'Z': 0, 'J': 0, 'Q': 0}

df = DataFrame({"keyword": [None, "kryptos"], "frequency": [expected,
dict(Counter(decrypt(ciphertxt, "kryptos")))]})
print(type(df["frequency"][0]))

#try vigeneres until frequency similar to english?

#with open("words_alpha.txt") as words:
#	for word in words:
#		word = word[:-1]
#		df.loc[len(df.index)] = [word, dict(Counter(decrypt(ciphertxt, word)))]
#		print(f"\"{word}\"")

#df.to_csv("keyword-frequency.csv", index=False)


















































































