import pandas as pd
df = pd.read_csv("keyword-frequency.csv")
df = df.sort_values(["frequency"])
df = df[df["frequency"].str.startswith("{'E'")]
